﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1._3
{
    
   public class Class1
    {
        public string name=null;
        public int goal = 0;

       public Class1()
        {

        }
    }
}
