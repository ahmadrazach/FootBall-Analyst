﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using project1._3.Properties;

using System.Threading;



namespace project1._3
{
    
    public partial class charts : Form
    {
        
        string sFile;
        List<Class1> listobj = new List<Class1>();
        ////for usage of panelr
        //List<Panel> listPanel = new List<Panel>();
        //int click;
        public charts()
        {
            InitializeComponent();
            
        }
        public void check_data()
        {
            
            bool check = false;
          int[] y = { listobj.ElementAt(0).goal, listobj.ElementAt(1).goal, listobj.ElementAt(2).goal, listobj.ElementAt(3).goal, listobj.ElementAt(4).goal, listobj.ElementAt(5).goal, listobj.ElementAt(6).goal, listobj.ElementAt(7).goal, listobj.ElementAt(8).goal, listobj.ElementAt(9).goal, listobj.ElementAt(10).goal, listobj.ElementAt(11).goal, listobj.ElementAt(12).goal, listobj.ElementAt(13).goal, listobj.ElementAt(14).goal };
            for(int i=0;i<15;i++)
            {

          
                if(y[i]<0 || y[i]>100)
                {
                    MessageBox.Show("There's invalid data in the fucking 2nd row ");
                    panel1.Hide();
                    return;
                }
                if(y[i]>1)
                {
                    check = true;
                    break;
                }
                
            }
            if (check == false)
                panel1.Show();
            else
                panel1.Hide();
        }
        public charts(List<Class1> list1)
        {
            InitializeComponent();
            listobj = list1;

        }

        private void charts_Load(object sender, EventArgs e)
        {
            check_data();
            string[] x = { listobj.ElementAt(0).name, listobj.ElementAt(1).name, listobj.ElementAt(2).name, listobj.ElementAt(3).name, listobj.ElementAt(4).name, listobj.ElementAt(5).name, listobj.ElementAt(6).name, listobj.ElementAt(7).name, listobj.ElementAt(8).name, listobj.ElementAt(9).name, listobj.ElementAt(10).name, listobj.ElementAt(11).name, listobj.ElementAt(12).name, listobj.ElementAt(13).name, listobj.ElementAt(14).name };
              int[] y = { listobj.ElementAt(0).goal, listobj.ElementAt(1).goal, listobj.ElementAt(2).goal, listobj.ElementAt(3).goal, listobj.ElementAt(4).goal, listobj.ElementAt(5).goal, listobj.ElementAt(6).goal, listobj.ElementAt(7).goal, listobj.ElementAt(8).goal, listobj.ElementAt(9).goal, listobj.ElementAt(10).goal, listobj.ElementAt(11).goal, listobj.ElementAt(12).goal, listobj.ElementAt(13).goal, listobj.ElementAt(14).goal };

            
              textBox1.Text = y.Max().ToString();
              int max = y.Max();
              int index = 0;
            for(int i=0;i<=14;i++)
            {
                if(y[i]==max)
                {
                    index = i;
                    break;
                }
                else
                {

                }
            }

            label11.Text = x[index];
            //for average
            textBox4.Text = y.Min().ToString();
            int mini = y.Min();
            for (int i = 0; i <= 14; i++)
            {
                if (y[i] == mini)
                {
                    index = i;
                    break;
                }
                else
                {

                }
            }

            label8.Text = x[index];

            textBox3.Text = y.Average().ToString();
          //calculating standard devition
            int sum=0, sumSquares=0;
            // Calculate the total for the sum
            for (int i = 0; i < 15; i++)
                sum += y[i];
            int squareSums = sum * sum;
            for (int i = 0; i < 15; i++)
                sumSquares += (y[i] * y[i]);

            // Now we can calculate the standard deviation
            double numerator = (14 * sumSquares - squareSums);
            double denominator = (14 * (14 - 1));
            double stdDev = Math.Sqrt(numerator / denominator);

            // Display the values(standard deviationand stuff)
            //txtC.Text = values.Count.ToString();
            //txtSum.Text = sum.ToString("F");
           // txtSumSquares.Text = sumSquares.ToString("F");
           // txtSquareSums.Text = squareSums.ToString("F");
            textBox2.Text = stdDev.ToString("F");
        }



        private void chart1_Click(object sender, EventArgs e)
        {


            //        fillDataGridView();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //if (click < listPanel.Count - 1)
            //    listPanel[++click].BringToFront();
            this.chart1.Series.Clear();
            Series series = new Series();
            series.ChartArea = "chart1";


            // Data arrays.
            string[] x = { listobj.ElementAt(0).name, listobj.ElementAt(1).name, listobj.ElementAt(2).name, listobj.ElementAt(3).name, listobj.ElementAt(4).name, listobj.ElementAt(5).name, listobj.ElementAt(6).name, listobj.ElementAt(7).name, listobj.ElementAt(8).name, listobj.ElementAt(9).name, listobj.ElementAt(10).name, listobj.ElementAt(11).name, listobj.ElementAt(12).name, listobj.ElementAt(13).name, listobj.ElementAt(14).name };
            int[] y = { listobj.ElementAt(0).goal, listobj.ElementAt(1).goal, listobj.ElementAt(2).goal, listobj.ElementAt(3).goal, listobj.ElementAt(4).goal, listobj.ElementAt(5).goal, listobj.ElementAt(6).goal, listobj.ElementAt(7).goal, listobj.ElementAt(8).goal, listobj.ElementAt(9).goal, listobj.ElementAt(10).goal, listobj.ElementAt(11).goal, listobj.ElementAt(12).goal, listobj.ElementAt(13).goal, listobj.ElementAt(14).goal };

            //        // Set palette.
            this.chart1.Palette = ChartColorPalette.SeaGreen;

            //        // Set title.
            this.chart1.Titles.Add("Players");

            //        // Add series.
            for (int i = 0; i < x.Length; i++)
            {
                //            // Add series.
                Series seri = this.chart1.Series.Add(x[i]);

                //            // Add point.
                seri.Points.Add(y[i]);
            }
            //saving a scrrenshot
            
            this.chart1.SaveImage("Histogram capture.png", ChartImageFormat.Png);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //PictureBox pic=new PictureBox();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //if (click < listPanel.Count - 1)
            //    listPanel[--click].BringToFront();

            chart1.ResetAutoValues();
            chart1.Series.Clear();
            chart1.Legends.Clear();

            //Add a new Legend(if needed) and do some formating
            chart1.Legends.Add("MyLegend");
            chart1.Legends[0].LegendStyle = LegendStyle.Table;
            chart1.Legends[0].Docking = Docking.Bottom;
            chart1.Legends[0].Alignment = StringAlignment.Center;
            chart1.Legends[0].Title = "MyTitle";
            chart1.Legends[0].BorderColor = Color.Transparent;

            Series standardSeries = new Series();
            standardSeries.Name = "MySeriesName";
            standardSeries.ChartType = SeriesChartType.RangeColumn;
            standardSeries.BorderWidth = 1;
            standardSeries.BorderDashStyle = ChartDashStyle.Solid;
            standardSeries.BorderColor = Color.Black;
            standardSeries.Color = Color.Blue;

            chart1.Series.Add(standardSeries);
            
            string[] x = { listobj.ElementAt(0).name, listobj.ElementAt(1).name, listobj.ElementAt(2).name, listobj.ElementAt(3).name, listobj.ElementAt(4).name, listobj.ElementAt(5).name, listobj.ElementAt(6).name, listobj.ElementAt(7).name, listobj.ElementAt(8).name, listobj.ElementAt(9).name, listobj.ElementAt(10).name, listobj.ElementAt(11).name, listobj.ElementAt(12).name, listobj.ElementAt(13).name, listobj.ElementAt(14).name };
            int[] y = { listobj.ElementAt(0).goal, listobj.ElementAt(1).goal, listobj.ElementAt(2).goal, listobj.ElementAt(3).goal, listobj.ElementAt(4).goal, listobj.ElementAt(5).goal, listobj.ElementAt(6).goal, listobj.ElementAt(7).goal, listobj.ElementAt(8).goal, listobj.ElementAt(9).goal, listobj.ElementAt(10).goal, listobj.ElementAt(11).goal, listobj.ElementAt(12).goal, listobj.ElementAt(13).goal, listobj.ElementAt(14).goal };
            chart1.Series["MySeriesName"].LegendText = "Brazil Order Statistics";
            chart1.Series["MySeriesName"].ChartType = SeriesChartType.Bar;
            chart1.Series["MySeriesName"].IsValueShownAsLabel = true;
            //chart1.Series[seriesname].Points.DataBindY(y);
            chart1.Series["MySeriesName"].Points.DataBindXY(x, y);

            //saving a screenshot
            this.chart1.SaveImage("Bar Chart.png", ChartImageFormat.Png);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            chart1.ResetAutoValues();
            chart1.Series.Clear();
            chart1.Legends.Clear();

            //Add a new Legend(if needed) and do some formating
            chart1.Legends.Add("MyLegend");
            chart1.Legends[0].LegendStyle = LegendStyle.Table;
            chart1.Legends[0].Docking = Docking.Bottom;
            chart1.Legends[0].Alignment = StringAlignment.Center;
            chart1.Legends[0].Title = "MyTitle";
            chart1.Legends[0].BorderColor = Color.Transparent;

            //Add a new chart- series
            string seriesname = "MySeriesName";
            chart1.Series.Add(seriesname);
            //set the chart - type to "Pie"
            chart1.Series[seriesname].ChartType = SeriesChartType.Pie;
            string[] x = { listobj.ElementAt(0).name, listobj.ElementAt(1).name, listobj.ElementAt(2).name, listobj.ElementAt(3).name, listobj.ElementAt(4).name, listobj.ElementAt(5).name, listobj.ElementAt(6).name, listobj.ElementAt(7).name, listobj.ElementAt(8).name, listobj.ElementAt(9).name, listobj.ElementAt(10).name, listobj.ElementAt(11).name, listobj.ElementAt(12).name, listobj.ElementAt(13).name, listobj.ElementAt(14).name };
            int[] y = { listobj.ElementAt(0).goal, listobj.ElementAt(1).goal, listobj.ElementAt(2).goal, listobj.ElementAt(3).goal, listobj.ElementAt(4).goal, listobj.ElementAt(5).goal, listobj.ElementAt(6).goal, listobj.ElementAt(7).goal, listobj.ElementAt(8).goal, listobj.ElementAt(9).goal, listobj.ElementAt(10).goal, listobj.ElementAt(11).goal, listobj.ElementAt(12).goal, listobj.ElementAt(13).goal, listobj.ElementAt(14).goal };

            chart1.Series[seriesname].LegendText = "Player Statistics";
            chart1.Series[seriesname].Points.DataBindXY(x, y);
            //saving scrrenshot
            this.chart1.SaveImage("Pie chart.png", ChartImageFormat.Png);


        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click_1(object sender, EventArgs e)
        {

        }

       
    }
}
