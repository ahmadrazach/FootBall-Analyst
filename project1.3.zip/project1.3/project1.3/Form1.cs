﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using Excel = Microsoft.Office.Interop.Excel;


namespace project1._3
{

    public partial class Form1 : Form
    {

        List<Class1> lst1;
        public Form1()
        {
            InitializeComponent();
            lst1=new List<Class1>();
        }
        
        // CREATE EXCEL OBJECTS.
        Excel.Application xlApp = new Excel.Application();
        Excel.Workbook xlWorkBook;
        Excel.Worksheet xlWorkSheet;

        OpenFileDialog OpenFileDialog1 = new OpenFileDialog();
        string sFileName;
        int iRow, iCol = 2;
        private void button1_Click(object sender, EventArgs e)
        {
           
            OpenFileDialog1.Title = "Excel File to Edit";
            OpenFileDialog1.FileName = "";
            OpenFileDialog1.Filter = "XLS files (*.xls, *.xlt)|*.xls;*.xlt|XLSX files (*.xlsx, *.xlsm, *.xltx, *.xltm)|*.xlsx;*.xlsm;*.xltx;*.xltm|ODS files (*.ods, *.ots)|*.ods;*.ots|CSV files (*.csv, *.tsv)|*.csv;*.tsv|HTML files (*.html, *.htm)|*.html;*.htm";
            
            if (OpenFileDialog1.ShowDialog() == DialogResult.OK)
            {
                sFileName = OpenFileDialog1.FileName;

                if (sFileName.Trim() != "")
                {
                    readExcel(sFileName);
                }
            }
        }

        private void readExcel(string sFile)
        {
            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Open(sFile);
            xlWorkSheet = xlWorkBook.Worksheets["Sheet1"];


            // FIRST, CREATE THE DataGridView COLUMN HEADERS.
            int iCol;
            for (iCol = 1; iCol <= xlWorkSheet.Columns.Count; iCol++)
            {
                if (xlWorkSheet.Cells[1, iCol].value == null)
                {
                    break;      // BREAK LOOP.
                }
                else
                {
                    DataGridViewColumn col = new DataGridViewTextBoxColumn();
                    col.HeaderText = xlWorkSheet.Cells[1, iCol].value;
                    int colIndex = dataGridView1.Columns.Add(col);     // ADD A NEW COLUMN.
                }
            }

            // ADD ROWS TO THE GRID.
            for (iRow = 2; iRow <= xlWorkSheet.Rows.Count; iRow++)  // START FROM THE SECOND ROW.
            {
                if (xlWorkSheet.Cells[ iRow, 1].value == null)
                {
                    break;      // BREAK LOOP.
                }
                else
                {
                    // CREATE A STRING ARRAY USING THE VALUES IN EACH ROW OF THE SHEET.
                    string[] row = new string[] { xlWorkSheet.Cells[iRow, 1].value,  
                xlWorkSheet.Cells[iRow, 2].value.ToString()};
                //xlWorkSheet.Cells[iRow, 3].value, xlWorkSheet.Cells[iRow, 4].value, xlWorkSheet.Cells[iRow, 5].value.ToString() , xlWorkSheet.Cells[iRow, 6].value.ToString()};

                    Class1 obj = new Class1();
                    obj.name = xlWorkSheet.Cells[iRow, 1].value;
                    obj.goal = Int32.Parse(xlWorkSheet.Cells[iRow, 2].value.ToString());
                 //   obj.goal=xlWorkSheet.Cells[iRow, 5].value.ToString() ;
                    lst1.Add(obj);
                    // ADD A NEW ROW TO THE GRID USING THE ARRAY DATA.
                    dataGridView1.Rows.Add(row);
                }
            }

            xlWorkBook.Close();
            xlApp.Quit();

            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkBook);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkSheet);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            charts chartvala = new charts(lst1);
            this.Hide();
            chartvala.Show();


        }
        
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

    }
}
